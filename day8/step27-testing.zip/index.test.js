let fun = require("./index");
let expect = require("expect");

describe("Checking for UserName", () => {
    let user = null;

    beforeEach(function(){
        console.log("log from before each")
        let user = fun.user;
    })
    it("should declare user", function(){
        console.log("testing : should declare user");
        expect(user).toBeDefined();
    })
    it("should be batman", function(){
        console.log("testing : should be batman");
        let user = fun.user;
        expect(user).toBe('Batman');
    })

    afterEach(function(){
        console.log("log from after each")
    })
})

describe("testing adder", function(){
    it("should give 10 when passed 5,5", function(){
        let res = fun.adder(5,5);
        expect(res).toBe(10);
    })
})