// module.exports.user = "Batman";

// module.exports.adder = function(num1, num2){
//     return num1 + num2;
// }

module.exports = {
    user : "Batman",
    adder : function(num1, num2){
        return num1 + num2;
    }
}
