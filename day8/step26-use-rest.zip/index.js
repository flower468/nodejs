const express = require("express");
let app = express();
app.use(express.static(__dirname+"/public"));

app.listen(5050, function(error){
    if(error){
        console.log("ERROR : ", error)
    }else{
        console.log("Server is live on localhost : 5050");
    }
})