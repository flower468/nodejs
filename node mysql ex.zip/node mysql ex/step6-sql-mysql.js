let mysql = require("mysql");
let connection = mysql.createConnection({
    host : "localhost",
    port : "3308",
    user : "root",
    password : "",
    database : "tatadb"
});
connection.connect(function(error){
   if(error){
    console.log(error);
   }else{
    console.log("Connected to MySQL DB Server");
    // let sql = "CREATE TABLE participants (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(200), email VARCHAR(200))"
    // let sql = "INSERT INTO participants (name, email) VALUES ('Vijay', 'vijay.shivu@gmail.com')";
    // let sql = "INSERT INTO participants (name, email) VALUES ('Bruce', 'bruce@waynefoundation.com')";
    
    /*
    let sql = "INSERT INTO participants (name, email) VALUES ?";
    let heroes = [
        ["Clark", "clark@metropolisnews.com"],
        ["Peter", "peter@newyorktimes.com"],
        ["Tony", "tony@stark.com"],
    ]
    */
    // connection.query(sql, [heroes],function(error, result){
    // let sql = "SELECT * FROM participants";
    // let sql = "SELECT name FROM participants";
    // let sql = "SELECT name, email FROM participants";
    // let sql = "SELECT name FROM participants WHERE id = 1";
    // let sql = "SELECT name FROM participants WHERE id < 5";
    // let sql = "SELECT name FROM participants WHERE id > 5";
    // let sql = "SELECT name FROM participants WHERE id <= 5";
    // let sql = "SELECT name FROM participants WHERE id >= 5";
    // let sql = "SELECT name FROM participants WHERE name LIKE 'b%'";
    // let sql = "DELETE FROM participants WHERE name = 'Vijay'";
    let sql = "UPDATE participants SET name = 'Batman' WHERE id = 3";
    connection.query(sql,function(error, result){
        if(error){
            console.log("Error : ", error)
        }else{
            console.log(result);
        }
    })
   }
});
