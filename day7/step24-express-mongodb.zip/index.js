const express = require("express");
const mongoose = require("mongoose");
//-----------------------------------
// CONFIG
let app = express();
const config = {
    "port" : process.env.PORT || 3535,
    "host" : "localhost"
};
// MONGODB Connection
//-----------------------------------
let Schema = mongoose.Schema;
let ObjectId = Schema.ObjectId;
let Hero = mongoose.model("Hero", new Schema({
    id : ObjectId,
    firstname  : String,
    lastname : String,
    city : String,
    power : Number
}));
// use in case of older mongoose version
// mongoose.Promise = global.Promise;
let url = "mongodb://127.0.0.1:27017/nodeDB";
mongoose.connect( url ,{ useNewUrlParser: true, useUnifiedTopology: true } )
.then(()=> console.log("Connection Success") )
.catch((error)=> console.log("Connection Error : ",error) );
//-----------------------------------
// MIDDLEWARES
app.use( express.json() );// 
app.use(express.static(__dirname+"/public"));
// app.use(cors());

// READ
app.get('/data', (req, res) => {
    Hero.find(function(error, data){
        if(error){
            console.log(error);
        }else{
            res.json(data);
        }
    })
});
// CREATE
app.post('/data', (req, res) => {
    let hero = new Hero(req.body);
    hero.save().then(dbres => {
        res.status(200).json( { 'message' : 'hero was added in db'})
    }).catch(error => {
        res.status(400).send( {"Error" : "Adding in database failed"} )
    })
});

// UPDATE

// DELETE

//-----------------------------------
app.listen(config.port, config.host, function(error){
    if(error){
        console.log("Error : ", error);
    }else{
        console.log("Server is now running on localhost : ",config.port);
    }
})
